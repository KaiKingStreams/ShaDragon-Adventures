§align:center
##### §nDraconic Flux Capacitor§n

§stack[draconicevolution:draconium_capacitor,1,1]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
This capacitor is similar to the §link[draconicevolution:wyvern_tools/wyvern_flux_capacitor]{alt_text:"Wyvern Flux Capacitor"} except it has a base capacity of 256M RF and can be upgraded to 640M.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_capacitor,1,1]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}