§align:center
§img[https://enderio.com/images/logo-tagline.png]{width:80%,link_to:"https://enderio.com/"} 
§rule{colour:0x606060,height:3,width:100%,top_pad:0}

§align:left
Ender IO非常非常方便的科技mod。 列出它的所有功能可以填满整本书，并且因为所有程序员在文档方面都很懒惰，所以这些书籍不存在。

但不要绝望！我们还是有文档滴：

§table{width:100%,render_cells:false}
| :- | :-------------------- |
| §stack[minecraft:book]{size:18,enable_tooltip:false} | 我们的机器和物品上有提示。在许多情况下，按**Shift**将显示更多信息。|
| §stack[minecraft:knowledge_book]{size:18,enable_tooltip:false} |JEI有合成表。只需查看项目的合成（“R”）或使用（“U”）。这也适用于能量（μI），盔甲升级，所有的Ender IO的机器等。|
| §stack[minecraft:bookshelf]{size:18,enable_tooltip:false} | 在§link[https://github.com/SleepyTrousers/EnderIO/wiki]{alt_text:"WIKI"}能查看更多。但不是很多，大多数是针对其他mod的开发人员和modpack的。|
| §stack[minecraft:writable_book]{size:18,enable_tooltip:false} |哦，还有**这个**文档。|

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
