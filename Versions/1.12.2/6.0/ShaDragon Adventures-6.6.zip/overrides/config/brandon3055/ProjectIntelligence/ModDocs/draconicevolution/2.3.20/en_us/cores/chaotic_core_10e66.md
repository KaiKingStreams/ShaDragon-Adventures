§align:center
##### §nChaotic Core§n

§stack[draconicevolution:chaotic_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Ready for something a little more challenging? You may want to consider the Chaotic tier! You will need to fight a §link[draconicevolution:chaos_guardian]{alt_text:"Chaos Guardian"} to get access to this tier, but the payout is worth it!

For the 1.12.2 version of Draconic Evolution, there will not be a Chaotic tier.  Draconic Additions has implimented their own version of the Chaotic tier, so if you really can't wait or refuse to try out the 1.16+ version, then give that mod a go.

There isn't a lot you can do at the Chaotic tier without Draconic Additions, but if you like insane power gen, then check out the §link[draconicevolution:draconic_reactor]{alt_text:"Draconic Reactor"}!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:chaotic_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}