﻿§align:center
##### §nChaotic Leggings§n

§stack[draconicadditions:chaotic_legs]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Speed Boost
+360 Base Shield Capacity
+6 Armor Toughness
+12 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:chaotic_legs]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}