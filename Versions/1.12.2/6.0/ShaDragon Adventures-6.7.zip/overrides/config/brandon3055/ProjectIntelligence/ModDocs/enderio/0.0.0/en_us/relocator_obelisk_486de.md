§stack[enderio:block_relocator_obelisk]{size:18,enable_tooltip:false}

§recipe[enderio:block_relocator_obelisk]{spacing:4}