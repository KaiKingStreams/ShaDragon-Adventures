§stack[enderio:block_transceiver]{size:18,enable_tooltip:false}

§recipe[enderio:block_transceiver]{spacing:4}