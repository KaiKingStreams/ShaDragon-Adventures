§align:center
##### §nDraconium Block§n

§stack[draconicevolution:draconium_block]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Draconium in its block form. 
This block is resistant to most mobs, including the Wither and Ender Dragon.
Equivalent to 4 book shelves when used as an enchanting booster.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_block]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}