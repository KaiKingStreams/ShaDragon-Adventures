§align:center
//##### §nDraconic Evolution§n
§table{width:100%,render_cells:false} 
<table column_layout="18,1*,18">
<tr>
	<td align="left">§img[http://ss.brandon3055.com/00671]{border_colour_hover:0x909090,width:100%,tooltip:"Follow me on Twitter!",link_to:"https://twitter.com/Brandon3055"}</td>
	<td align="center">§img[http://ss.brandon3055.com/772e8]{width:50%}</td>
	<td align="top right">§img[http://ss.brandon3055.com/4b67c]{border_colour_hover:0x909090,width:100%,tooltip:"Support my work on patreon!",link_to:"https://www.patreon.com/brandon3055"}</td>
</tr>
</table>

ABC...LMN§cDraconic Evolution§rQR...WXYZ
§rule{colour:0x606060,height:3,width:100%,bottom_pad:4}
Draconic Evolution is a mod that blends together magic and tech giving you some extremely powerful end game content. Below is a summery of just some of the content added by DE.
§rule{colour:0x606060,height:3,width:100%,top_pad:3,bottom_pad:0}

// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="25,1*"><tr><td></td><td>
§a-Powerful tools and armor§a
DE currently adds 2 tiers of highly upgradable tools and armor.

§a-Teleportation§a
Among other things, DE is currently the only mod I know of that adds point-to-point teleportation where the end points can be moved by things like frames and remain connected.

§a-Time and Weather Control§a
DE adds the ability to start or stop rain/stormy weather, as well as skipping the night or day if you so desire.

§a-Mob Farming§a
Both mob spawning and mob grinding!
          
§a-Practically infinite energy storage (at a price to match).§a
Let's face it; nothing in minecraft is truly infinite, but this gets pretty close!

§a-Extreme(ly Dangerous) power generation§a
With great power comes great destructive potential. DE's reactor is no exception. It will happily perform a rapid unscheduled disassembly of your entire world if you're not careful!

§a-Fancy visual effects!§a
Who doesn't like fancy visual effects?!

§a-One of the most powerful bosses in modded minecraft§a
Enchanted diamond armor? Ha! You would probably have better luck wrapping yourself in toilet paper.
</td></tr></table>

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="1*,130">
<tr>
	<td>I would like to thank averyone who has created spotlights for this mod! You can find a list of mod spotlights by following this link.</td>
	<td align="middle right">§link[draconicevolution:spotlights]{alt_text:Mod Spotlights,colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:5,left_pad:12,right_pad:13,link_style:vanilla}</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%,top_pad:4}
// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="1*,100">
<tr>
	<td>I would also like to thank everyone who has supported DE in one way or another over the years!</td>
	<td align="middle right">§link[draconicevolution:contributors]{alt_text:Mod Contributors,colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:5,link_style:vanilla}</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%,top_pad:5}
// ##########################################################################

§align:left
§table{width:100%,colour:0x0,render_cells:false} 
<table column_layout="1*,90">
<tr padding="2,0,1,3" align="middle">
	<td>§colour[0x088700]§link[http://partners.creeper.host/r/brandon30557nc]{tooltip:"Use this link to get a 15% discount on your first month!",alt_text:"I am partnered with Creeper Host. If you need to rent a server at a fair price, I suggest you check them out!"}</td>
	<td>§img[http://ss.brandon3055.com/0f927]{tooltip:"Use this link to get a 15% discount on your first month!",width:100%,link_to:"http://partners.creeper.host/r/brandon30557nc"}</td>
</tr>
</table>