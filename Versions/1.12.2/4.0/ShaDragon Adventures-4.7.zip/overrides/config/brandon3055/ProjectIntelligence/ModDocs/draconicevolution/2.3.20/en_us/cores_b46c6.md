§align:center
##### §nCores§n

§stack[draconicevolution:draconic_core]{size:32} §stack[draconicevolution:wyvern_core]{size:32} §stack[draconicevolution:awakened_core]{size:32} §stack[draconicevolution:chaotic_core]{size:32}

§stack[draconicevolution:wyvern_energy_core]{size:32} §stack[draconicevolution:draconic_energy_core]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Cores are a key crafting component in almost all Draconic Evolution recipes.
Cores come in 4 tiers, with Draconic (aka basic) being the lowest and Chaotic being the highest.

Including the 4 regular cores, there are also 2 types of Energy Cores. These are primarily used to craft items that store energy such as the tools and armor.

You can also right-click a vanilla spawner with any of the normal cores to create a §link[draconicevolution:stabilized_spawner]{alt_text:"Stabilized Spawner"}.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}