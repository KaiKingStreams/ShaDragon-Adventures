§align:center
##### §nDislocator§n

§stack[draconicevolution:dislocator]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
You have managed to infuse the powers of The End with your knowledge of the Draconic to create a basic teleporter, but at a cost.

The energies binding them are unstable and only last for 10 uses, and will take some of your life energy with each use.

It can only be linked to a single location, but it does work across dimensions. Once used up, you must create a new one.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:dislocator]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}