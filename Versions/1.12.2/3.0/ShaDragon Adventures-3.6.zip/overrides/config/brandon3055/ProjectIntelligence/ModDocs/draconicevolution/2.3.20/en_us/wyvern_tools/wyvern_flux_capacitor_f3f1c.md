§align:center
##### §nWyvern Flux Capacitor§n

§stack[draconicevolution:draconium_capacitor]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Tired of your tools and armor running out of energy when you need them most, you have figured out how to create an item capable of storing an immense amount of energy and transferring it to your items as they need it.

The Wyvern Flux Capacitor has 4 operating modes and you can sneak-right click the capacitor to cycle between them.

§6Inactive
§6Charge Armor
§6Charge Armor + Held Item
§6Charge Held Item

This capacitor has a base capacity of 64M RF and can be upgraded to 128M.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_capacitor]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}