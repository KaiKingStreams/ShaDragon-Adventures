§align:center
##### §nDraconium Dust§n

§stack[draconicevolution:draconium_dust]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Draconium Dust drops from §link[draconicevolution:draconium/draconium_ore]{alt_text:Draconium Ore} when harvested.
1 dust smelts into 1 §link[draconicevolution:draconium]{alt_text:Draconium Ingot}.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_dust]{spacing:2}