§stack[enderio:block_killer_joe]{size:18,enable_tooltip:false}

§recipe[enderio:block_killer_joe]{spacing:4}