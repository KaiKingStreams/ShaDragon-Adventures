§align:center
//##### §n龙之进化§n
§table{width:100%,render_cells:false} 
<table column_layout="18,1*,18">
<tr>
	<td align="left">§img[http://ss.brandon3055.com/00671]{border_colour_hover:0x909090,width:100%,tooltip:"在推特上关注我！（需科学上网）",link_to:"https://twitter.com/Brandon3055"}</td>
	<td align="center">§img[http://ss.brandon3055.com/772e8]{width:50%}</td>
	<td align="top right">§img[http://ss.brandon3055.com/4b67c]{border_colour_hover:0x909090,width:100%,tooltip:"在patreon上给支持我的mod开发！",link_to:"https://www.patreon.com/brandon3055"}</td>
</tr>
</table>

ABC...LMN§cDraconic Evolution§rQR...WXYZ
§rule{colour:0x606060,height:3,width:100%,bottom_pad:4}
Draconic Evolution是一款将魔法和科技融合在一起的mod，为你提供极其强大的工具。 这是DE添加的一些内容的总结。
§rule{colour:0x606060,height:3,width:100%,top_pad:3,bottom_pad:0}

// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="25,1*"><tr><td></td><td>
§a-牛逼的工具和盔甲§a
DE目前增加了2种可升级的工具和盔甲。

§a-传送§a
除此之外，DE目前是我所知道的唯一可以点对点传送的mod。

§a-控制时间和天气§a
能够开始或停止下雨/暴风雨天气。 如果你愿意，可以跳过白天或白天。

§a-怪物农场§a
生成怪物以及粉碎怪物！
          
§a-几乎无限的能量存储（物有所值）§a
在我的世界中没有什么是真正无限的，但这变得非常接近！

§a-极端（危险）的发电§a
强大的能量带来巨大的破坏性潜力。 DE的反应堆也不例外。 如果你不小心的话，它会愉快地把你的整个世界夷为平地！

§a-牛逼的特效§a
谁不喜欢§m§4R§4§2G§2§1B§1§m这个！

§a-Minecraft中最强大的boss之一§a
魔法钻石盔甲？ 那是纸糊的！
</td></tr></table>

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="1*,130">
<tr>
	<td>我要感谢为这个mod做视频的每个人！ 你可以通过以下链接找到视频列表。</td>
	<td align="middle right">§link[draconicevolution:spotlights]{alt_text:Mod Spotlights,colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:5,left_pad:12,right_pad:13,link_style:vanilla}</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%,top_pad:4}
// ##########################################################################
§table{width:100%,render_cells:false} 
<table column_layout="1*,100">
<tr>
	<td>我还要感谢所有多年来以这种或那种方式支持DE的人！</td>
	<td align="middle right">§link[draconicevolution:contributors]{alt_text:Mod Contributors,colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:5,link_style:vanilla}</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%,top_pad:5}
// ##########################################################################

§align:left
§table{width:100%,colour:0x0,render_cells:false} 
<table column_layout="1*,90">
<tr padding="2,0,1,3" align="middle">
	<td>§colour[0x088700]§link[http://partners.creeper.host/r/brandon30557nc]{tooltip:"使用此链接可在第一个月获得15％的折扣！",alt_text:我与Creeper Host合作。 如果你需要以合理的价格租用服务器，我建议你看看！}</td>
	<td>§img[http://ss.brandon3055.com/0f927]{tooltip:"使用此链接可在第一个月获得15％的折扣！",width:100%,link_to:"http://partners.creeper.host/r/brandon30557nc"}</td>
</tr>
</table>