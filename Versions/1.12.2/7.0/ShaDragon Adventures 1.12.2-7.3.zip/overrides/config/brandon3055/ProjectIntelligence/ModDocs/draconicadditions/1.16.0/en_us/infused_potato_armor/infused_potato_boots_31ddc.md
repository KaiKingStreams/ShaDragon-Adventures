§align:center
##### §nInfused Potato Boots

§stack[draconicadditions:infused_potato_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+1 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:infused_potato_boots]{spacing:4}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}