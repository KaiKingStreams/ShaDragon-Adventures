§align:center
##### §nDraconium§n

§stack[draconicevolution:draconium_ore,1,32767]{size:32} §stack[draconicevolution:draconium_dust]{size:32} §stack[draconicevolution:nugget]{size:32} §stack[draconicevolution:draconium_ingot]{size:32} §stack[draconicevolution:draconium_block]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Draconium is the base material used one way or another to craft every item and block in Draconic Evolution.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_ingot]{spacing:2}§recipe[draconicevolution:draconium_block]{spacing:2}§recipe[draconicevolution:draconium_ore]{spacing:2}§recipe[draconicevolution:nugget]{spacing:2}§recipe[draconicevolution:draconium_dust]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}